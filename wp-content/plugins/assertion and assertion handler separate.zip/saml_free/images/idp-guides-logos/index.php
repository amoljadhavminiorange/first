<?php
/**
 * The index.php file for the idp-guides-logos directory
 *
 * @package miniorange-saml-20-single-sign-on\images\idp-guides-logos
 */
