<?php
/**
 * The index.php file for the addons_logos directory
 *
 * @package miniorange-saml-20-single-sign-on\images\addons_logos
 */
