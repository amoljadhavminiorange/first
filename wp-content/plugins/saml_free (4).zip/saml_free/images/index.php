<?php
/**
 * The index.php file for the images directory
 *
 * @package miniorange-saml-20-single-sign-on\images
 */
