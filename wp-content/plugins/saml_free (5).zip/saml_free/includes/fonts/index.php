<?php
/**
 * The index.php file for the fonts directory
 *
 * @package miniorange-saml-20-single-sign-on\includes\fonts
 */
