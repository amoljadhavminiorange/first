<?php
/**
 * The index.php file for the handlers directory
 *
 * @package miniorange-saml-20-single-sign-on\handlers
 */
