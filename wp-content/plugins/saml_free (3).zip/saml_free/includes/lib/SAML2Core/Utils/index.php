<?php
/**
 * The index.php file for the SAML2Core Utils directory
 *
 * @package miniorange-saml-20-single-sign-on\includes\lib\SAML2Core\Utils
 */
